<!DOCTYPE html>
<html lang="en">
<?php 
include "headEX5.php";
?>

<body>

    <?php
include "funçõesEX5.php";

    exibirDados();
    ?>
       <?php 

include "links.php";

?>
</body>
</html>