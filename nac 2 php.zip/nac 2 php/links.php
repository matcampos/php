
    <div  style="margin:auto" class="col-md-6 filter" ><label for="">Links: </label>
    <div>
    <a   style="margin:auto"href="ex5Create.php" class="btn btn-info">CADASTRAR</a>
    <a  style="margin:auto" href="ex5Alterar.php" class="btn btn-info">ALTERAR</a>
    <a  style="margin:auto" href="ex5Listar.php" class="btn btn-info">LISTAR</a>
    <a  style="margin:auto" href="ex5Deletar.php" class="btn btn-info">DELETAR</a></div>